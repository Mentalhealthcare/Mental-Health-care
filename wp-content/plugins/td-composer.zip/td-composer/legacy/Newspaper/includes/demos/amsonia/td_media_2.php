<?php
//td_demo_media::add_image_to_media_gallery('td_pic_5', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/46.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/46.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_6', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/45.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/45.jpg');
