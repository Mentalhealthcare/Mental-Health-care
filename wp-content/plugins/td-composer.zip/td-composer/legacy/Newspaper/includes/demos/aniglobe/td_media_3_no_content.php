<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/02/xxx_pattern-aniglobe_xxx.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/xxx_pattern-aniglobe_xxx.png');