<?php
//td_demo_media::add_image_to_media_gallery('td_pic_9', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/42-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/42-3.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_10', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/41-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/41-3.jpg');
