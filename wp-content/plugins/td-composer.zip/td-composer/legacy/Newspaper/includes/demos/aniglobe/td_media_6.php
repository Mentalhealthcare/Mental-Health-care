<?php
//td_demo_media::add_image_to_media_gallery('td_pic_3', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/48-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/48-3.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_4', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/47-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/47-3.jpg');