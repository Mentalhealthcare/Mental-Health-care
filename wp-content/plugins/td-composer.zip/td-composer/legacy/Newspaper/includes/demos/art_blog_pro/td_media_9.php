<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/art_blog_pro/media/p2.jpg');