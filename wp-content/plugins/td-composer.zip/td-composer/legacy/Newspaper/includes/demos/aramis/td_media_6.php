<?php
//td_demo_media::add_image_to_media_gallery('td_pic_3', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/43.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/43.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_4', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/42.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/42.jpg');