<?php
//td_demo_media::add_image_to_media_gallery('td_pic_5', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/41.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/41.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_6', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/40.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/40.jpg');
