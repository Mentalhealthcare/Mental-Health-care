<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/newsletter.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/reclama-sidebar.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/2.jpg');
