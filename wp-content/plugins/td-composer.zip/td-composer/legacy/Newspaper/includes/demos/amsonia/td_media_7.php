<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'http://localhost/wp_011_amsonia/wp-content/uploads/2022/03/p1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/amsonia/media/p1.jpg');
