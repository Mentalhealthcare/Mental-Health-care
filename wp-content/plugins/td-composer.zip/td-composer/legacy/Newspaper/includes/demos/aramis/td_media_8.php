<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/p1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/p1.jpg');
//td_demo_media::add_image_to_media_gallery('tdx_pic_2', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/p2.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/p2.jpg');
