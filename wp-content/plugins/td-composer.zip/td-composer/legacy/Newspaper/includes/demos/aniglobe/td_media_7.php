<?php
//td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/p1-6.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/p1-6.jpg');
