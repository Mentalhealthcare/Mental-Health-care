<?php
td_demo_media::add_image_to_media_gallery('td_pic_4', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/4.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_5', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/5.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_6', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/6.jpg');
