<?php
//td_demo_media::add_image_to_media_gallery('td_pic_1', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/45.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/45.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_2', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/44.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/44.jpg');
