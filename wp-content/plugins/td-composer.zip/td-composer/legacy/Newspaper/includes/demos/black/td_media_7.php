<?php
td_demo_media::add_image_to_media_gallery('td_pic_p4',                  "http://demo_content.tagdiv.com/Newspaper_6/black/p4.jpg");
td_demo_media::add_image_to_media_gallery('td_logo_header',             'http://demo_content.tagdiv.com/Newspaper_6/black/logo-header.png');
//ads
td_demo_media::add_image_to_media_gallery('td_sidebar_ad',             "http://demo_content.tagdiv.com/Newspaper_6/black/rec300.jpg");