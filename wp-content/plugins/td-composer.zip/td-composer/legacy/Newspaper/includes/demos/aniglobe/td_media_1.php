<?php
//td_demo_media::add_image_to_media_gallery('td_pic_1', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/50-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/50-3.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_2', 'http://localhost/wp_011_aniglobe/wp-content/uploads/2022/01/49-3.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/aniglobe/media/49-3.jpg');
