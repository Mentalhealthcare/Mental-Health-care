<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_26', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/author-e.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_27', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/author-1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_28', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/author-2.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_29', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/randy.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_30', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/forbes-logo.png');


