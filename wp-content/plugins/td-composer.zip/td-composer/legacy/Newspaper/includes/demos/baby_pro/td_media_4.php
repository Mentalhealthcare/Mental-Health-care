<?php
td_demo_media::add_image_to_media_gallery('td_pic_10', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/10.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/p1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_2', 'http://cloud.tagdiv.com/demos/Newspaper/baby_pro/media/p2.jpg');