<?php
//td_demo_media::add_image_to_media_gallery('td_pic_7', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/39.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/39.jpg');
//td_demo_media::add_image_to_media_gallery('td_pic_8', 'http://localhost/wp_011_aramis_pro/wp-content/uploads/2021/10/38.jpg');
td_demo_media::add_image_to_media_gallery('td_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/aramis/media/38.jpg');
