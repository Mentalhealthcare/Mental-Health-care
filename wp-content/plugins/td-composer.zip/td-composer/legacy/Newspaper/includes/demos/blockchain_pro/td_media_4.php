<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_6', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/xxx_dots_xxx.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_7', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/token.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_8', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/validators.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_9', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/man5.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_10', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/man2.jpg');


