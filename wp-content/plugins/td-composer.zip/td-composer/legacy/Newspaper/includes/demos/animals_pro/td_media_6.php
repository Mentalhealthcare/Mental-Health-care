<?php
//404 image
td_demo_media::add_image_to_media_gallery('td_pic_404',                             "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/404.png");
// ads
td_demo_media::add_image_to_media_gallery('td_reclama_1',                          "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/reclama1.jpg");
td_demo_media::add_image_to_media_gallery('td_reclama_2',                          "http://demo_content.tagdiv.com/Newspaper_6/animals_pro/reclama2.jpg");