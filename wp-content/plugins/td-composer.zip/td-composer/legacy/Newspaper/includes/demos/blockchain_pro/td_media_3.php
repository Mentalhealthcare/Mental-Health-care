<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_1', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/p1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_2', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/p2.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/xxx_lines_xxx.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/xxx_lines_sm_xxx.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_5', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/xxx_lines_center_xxx.png');


