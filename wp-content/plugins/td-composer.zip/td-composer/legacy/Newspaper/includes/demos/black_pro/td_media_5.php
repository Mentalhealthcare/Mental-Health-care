<?php
td_demo_media::add_image_to_media_gallery('tdx_pic_3', 'https://cloud.tagdiv.com/demos/Newspaper/black_pro/media/custom-rec-1.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_4', 'https://cloud.tagdiv.com/demos/Newspaper/black_pro/media/cusstom-rec-1@2x.jpg');

