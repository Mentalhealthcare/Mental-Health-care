<?php

td_demo_media::add_image_to_media_gallery('tdx_pic_16', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/man6.jpg');
td_demo_media::add_image_to_media_gallery('tdx_pic_17', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/ipad-hero-image.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_18', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/chainlink-e.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_19', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/waves.png');
td_demo_media::add_image_to_media_gallery('tdx_pic_20', 'https://cloud.tagdiv.com/demos/Newspaper/blockchain_pro/media/graph-e.png');


