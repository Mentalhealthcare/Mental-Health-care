<?php

require_once('api/tds_leads_api.php');
require_once('api/tds_payment_api.php');
